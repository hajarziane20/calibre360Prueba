package modelos;

import java.util.*;

public class GrafoRuta {

    
    private Map<String, List<Transporte>> rutas; 

    // Constructor de la clase GrafoRuta
    public GrafoRuta() {
        this.rutas = new HashMap<>();
    }

    /**
     * @param transporte Objeto de tipo Transporte (puede ser avión, barco, tren, coche)
     */
    public void agregarRuta(Transporte transporte) {
        String origen = transporte.getOrigen();
        if (!rutas.containsKey(origen)) {
            rutas.put(origen, new ArrayList<>());
        }
        rutas.get(origen).add(transporte);
    }

    /**
     * @param origen Ciudad de origen
     * @param destino Ciudad de destino
     * @return Una lista de rutas posibles entre las dos ciudades
     */
    public List<List<Transporte>> buscarTodasRutas(String origen, String destino) {
        List<List<Transporte>> todasLasRutas = new ArrayList<>();
        List<Transporte> rutaActual = new ArrayList<>();
        Set<String> ciudadesVisitadas = new HashSet<>();  // Evitar ciclos, no permite duplicados.
        buscarRutasRecursivas(origen, destino, todasLasRutas, rutaActual, ciudadesVisitadas);
        return todasLasRutas;
    }
 

    // Método recursivo para buscar todas las rutas posibles entre origen y destino, evitando ciclos
    private void buscarRutasRecursivas(String origen, String destino, List<List<Transporte>> todasLasRutas,
    											List<Transporte> rutaActual, Set<String> ciudadesVisitadas) {
        if (!rutas.containsKey(origen)) return;  // Si no hay rutas desde el origen, terminamos
        
        //Obtener la lista de posibles transportes desde la ciudad de origen
        List<Transporte> listaRutas = rutas.get(origen);
        ciudadesVisitadas.add(origen);  // Marcar la ciudad de origen como visitada

        //Recorrer todas las opciones de transporte desde la ciudad actual
        for (Transporte transporte : listaRutas) {
        	
        	//Si el destino de este transporte es el mismo que la ciudad destino, significa que hemos encontrado una ruta completa.
            if (transporte.getDestino().equals(destino)) {
                rutaActual.add(transporte);// Agregamos dicha ruta a la ruta actual.
                todasLasRutas.add(new ArrayList<>(rutaActual));  // Guardamos la ruta actual en la lista de todas las rutas posibles.
                rutaActual.remove(rutaActual.size() - 1);  // Quito la ultima ciudad añadida.
                
            } else if (!ciudadesVisitadas.contains(transporte.getDestino())) {
                // Si aún no hemos visitado el destino, continuamos buscando recursivamente
                rutaActual.add(transporte);
                buscarRutasRecursivas(transporte.getDestino(), destino, todasLasRutas, rutaActual, ciudadesVisitadas);//se pasa el destino como origen, lo que permite avanzar.
                rutaActual.remove(rutaActual.size() - 1);  // Deshacemos el último transporte para formar otra ruta
            }
        }

        ciudadesVisitadas.remove(origen);  // Desmarcar la ciudad como visitada (backtracking) para que permita volver a la ciudad anterior.
        //Antes de explorar: Marcamos la ciudad como visitada.Después de explorar todas las rutas desde ella: La desmarcamos para futuras búsquedas.
    }

}
