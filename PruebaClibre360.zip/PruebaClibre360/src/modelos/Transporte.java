package modelos;

//Es una clase Abstracta para que no se pueda instanciar, no tiene suficiente información para crear un objeto por si sola.
//Clase madre que lleva los atributos comunes.

public abstract class Transporte {

	//Al ser protected solo permito el acceso a sus hijas.
	protected String origen;
	protected String destino;
	
	// Constructor que asigna el origen y el destino al transporte
	public Transporte(String origen, String destino) {
		super();
		this.origen = origen;
		this.destino = destino;
	}
	
	
	 // Método abstracto que las subclases deben implementar para mostrar su información
    public abstract void mostrarInfo();


	public String getOrigen() {
		return origen;
	}


	public String getDestino() {
		return destino;
	}
	
    
    
}
