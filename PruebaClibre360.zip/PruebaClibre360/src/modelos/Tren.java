package modelos;

public class Tren extends Transporte{

	private String numTren;
	private String numAsiento;

	public Tren(String origen, String destino) {
		super(origen, destino);
		this.numTren = GeneradorIdentificadores.generarNumeroTren();
		this.numAsiento = GeneradorIdentificadores.generarNumeroAsiento("Tren");
	}

	@Override
	public void mostrarInfo() {
		System.out.println("->Coge Tren desde "+origen+" hasta "+ destino+" ------- Núm Tren: "+numTren+" | Asiento: "+numAsiento);
	}

}
