package modelos;

public class Coche extends Transporte{
	
	private String matricula;

	public Coche(String origen, String destino) {
		super(origen, destino);
		this.matricula = GeneradorIdentificadores.generarMatriculaCoche();
	}

	@Override
	public void mostrarInfo() {
		System.out.println("-> Coge Coche  desde "+origen+" hasta "+ destino+"------- Matricula: "+matricula);
	}
	
	

}
