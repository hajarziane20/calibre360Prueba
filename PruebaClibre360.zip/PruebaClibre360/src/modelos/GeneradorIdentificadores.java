package modelos;

import java.util.Random;

public class GeneradorIdentificadores {

    
    private static final Random random = new Random();

    
    public static String generarNumeroVuelo() {
        int numeroVuelo = random.nextInt(1000) + 100; // 100-1099
        return "V" +"-"+ numeroVuelo; 
    }

    public static String generarNumeroAsiento(String tipoTransporte) {
        char letraAleatoria = (char) ('A' + random.nextInt(26)); // A-Z

        if (tipoTransporte.equals("Avion")) {
            return letraAleatoria + "" + (random.nextInt(30) + 1); // 1-30
        } else if (tipoTransporte.equals("Tren")) {
            return letraAleatoria + "" + (random.nextInt(50) + 1); // 1-50
        } else {
            // Para cualquier otro param, para extensiones.
            return letraAleatoria + "" + (random.nextInt(150) + 1); 
        }
    }


    public static String generarNumeroTren() {
        return "TR-" + (random.nextInt(1000) + 1); // TR de TRen  1-1000
    }

    public static String generarMatriculaCoche() {
    	char letra1 = (char) ('A' + random.nextInt(26)); // A-Z
        char letra2 = (char) ('A' + random.nextInt(26)); 
        char letra3 = (char) ('A' + random.nextInt(26)); 
        int numero = random.nextInt(9999) + 1000; //1000-9999
        return numero + "-" + letra1 + "" + letra2+ "" + letra3; 
    }
    
    public static String generarNumeroBarco() {
        return "B-" + (random.nextInt(1000) + 1); // 1-1000
    }

    
}