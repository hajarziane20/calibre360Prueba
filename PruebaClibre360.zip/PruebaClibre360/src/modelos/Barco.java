package modelos;

public class Barco extends Transporte{


	private String numBarco;

	public Barco(String origen, String destino) {
		super(origen, destino);
		this.numBarco = GeneradorIdentificadores.generarNumeroBarco();
	}

	@Override
	public void mostrarInfo() {
		System.out.println("-> Coge Barco desde "+origen+" hasta "+ destino+" ------- Número de Barco: "+numBarco);
	}

	
	
}
