package modelos;

public class Avion extends Transporte{

	private String numVuelo;
	private String numAsiento;
	
	public Avion(String origen, String destino) {
		super(origen, destino);
		this.numVuelo = GeneradorIdentificadores.generarNumeroVuelo();
		this.numAsiento = GeneradorIdentificadores.generarNumeroAsiento("Avion");
	}

	@Override
	public void mostrarInfo() {
		System.out.println("-> Coge Avión desde "+origen+" hasta "+ destino+" ------- Número de Vuelo: "+numVuelo+" | Asiento: "+numAsiento);
	}
	
	
}
