package controladores;

import java.util.List;
import java.util.Scanner;
import modelos.*;

public class ControladorRutas {

    private GrafoRuta grafoRutas;

    public ControladorRutas() {
        this.grafoRutas = new GrafoRuta();  // Inicializamos el grafo de rutas vacío
    }

    public void crearRutas() {
        grafoRutas.agregarRuta(new Avion("Madrid", "Valencia"));
        grafoRutas.agregarRuta(new Avion("Valencia", "Madrid"));
        grafoRutas.agregarRuta(new Barco("Valencia", "Barcelona"));
        grafoRutas.agregarRuta(new Tren("Barcelona", "Valencia"));

        grafoRutas.agregarRuta(new Coche("Madrid", "Barcelona"));
        grafoRutas.agregarRuta(new Tren("Barcelona", "Madrid"));
        grafoRutas.agregarRuta(new Coche("Barcelona", "Paris"));
        grafoRutas.agregarRuta(new Avion("Barcelona", "Roma"));

        grafoRutas.agregarRuta(new Avion("Roma", "Malta"));
        grafoRutas.agregarRuta(new Avion("Malta", "Roma"));
        grafoRutas.agregarRuta(new Barco("Valencia", "Malta"));
    }

    /**
     * @param origen Ciudad de origen
     * @param destino Ciudad de destino
     */
    public void buscarYMostrarRutas(String origen, String destino) {
        List<List<Transporte>> rutasEncontradas = grafoRutas.buscarTodasRutas(origen, destino);
        if (rutasEncontradas.isEmpty()) {
            System.err.println("No existe una ruta válida entre las ciudades.");
        } else {
            // 
            for (int i = 0; i < rutasEncontradas.size(); i++) {
                System.out.println("\u001B[1mRuta " + (i + 1) + ":\u001B[0m");
                for (Transporte transporte : rutasEncontradas.get(i)) {
                    transporte.mostrarInfo();
                }
                System.out.println("¡Felicidades, has llegado a tu destino!\n");
            }
        }
    }

    /**
     * @param mensaje Mensaje que se muestra al usuario
     * @return La ciudad capitalizada
     */
    public String pedirYFormatearCiudad(Scanner scanner, String mensaje) {
        System.out.print("\u001B[32m🌍\u001B[0m " + mensaje + ": ");
        String ciudad = scanner.nextLine();
        return capitalizarPrimeraLetra(ciudad);
    }

    /**
     * @param ciudad Nombre de la ciudad
     * @return El nombre de la ciudad con la primera letra en mayúscula
     */
    private String capitalizarPrimeraLetra(String ciudad) {
        return ciudad.substring(0, 1).toUpperCase() + ciudad.substring(1).toLowerCase();
    }
}
