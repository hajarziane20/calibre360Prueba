package vistas;

import java.util.Scanner;

import controladores.ControladorRutas;

public class Vista {

    public static void MostrarResultado() {
    	  ControladorRutas controladorRutas = new ControladorRutas();
          controladorRutas.crearRutas();

          System.out.println("==============================================");
          System.out.println("    \u001B[34m🚗\u001B[0m Bienvenido al Calculador de Rutas \u001B[34m🚗\u001B[0m");
          System.out.println("==============================================\n");

          System.out.println("Por favor, introduce las ciudades para calcular tu ruta:");
          System.out.println("---------------------------------------");

          Scanner scanner = new Scanner(System.in);
 
          String origen = controladorRutas.pedirYFormatearCiudad(scanner, "Ciudad de origen");
          String destino = controladorRutas.pedirYFormatearCiudad(scanner, "Ciudad de destino");

          System.out.println();
          System.out.println("=======================================");
          System.out.println("Ruta solicitada: " + origen + " \u001B[38;5;13m➡️\u001B[0m " + destino); 
          System.out.println("=======================================\n");

          controladorRutas.buscarYMostrarRutas(origen, destino);
    }
}
