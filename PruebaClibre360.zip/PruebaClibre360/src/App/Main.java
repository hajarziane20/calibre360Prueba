package App;
import java.util.Scanner;

import controladores.ControladorRutas;
import modelos.*;
import vistas.Vista;
public class Main {

	 public static void main(String[] args) {
	       Vista.MostrarResultado();			
   }
}
